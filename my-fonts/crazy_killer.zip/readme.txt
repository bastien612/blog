All of our fonts are free at this time. This means that you can 
download and distribute them freely. If you use one of our 
fonts, please link to us!

http://www.fontemporium.com/